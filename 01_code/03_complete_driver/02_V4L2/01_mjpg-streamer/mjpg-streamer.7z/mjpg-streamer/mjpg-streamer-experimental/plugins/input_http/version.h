#define VERSION "No version"
